// Campus Portal - Express backend. Stores data in MongoDB Atlas (set MONGODB_URI), or in data.json if not set.
try { require('dotenv').config(); } catch {}
// Use Cloudflare DNS (1.1.1.1) for Node's lookups - fixes Atlas "querySrv ECONNREFUSED" errors on some networks
require('dns').setServers((process.env.DNS_SERVERS || '1.1.1.1,1.0.0.1').split(','));
const { MongoClient } = require('mongodb');
const express = require('express'), crypto = require('crypto'), fs = require('fs'), path = require('path');
const SECRET = process.env.SECRET || 'change-me-in-production';
const FILE = path.join(__dirname, 'data.json'), PORT = process.env.PORT || 3000;
const uid = () => crypto.randomBytes(5).toString('hex');
const hash = (p, s = crypto.randomBytes(8).toString('hex')) => s + ':' + crypto.scryptSync(p, s, 32).toString('hex');
const verifyPw = (p, h) => hash(p, h.split(':')[0]) === h;
const DAY = 864e5, day = n => new Date(Date.now() + n * DAY).toISOString();

// ---------- database ----------
let db, col = null, mongo = null;
let saving = false, pending = false;
async function flush() {                      // serialised writes: never two replaceOne calls at once
  if (saving) return; saving = true;
  try { while (pending) { pending = false; await col.replaceOne({ _id: 'main' }, { _id: 'main', ...db }, { upsert: true }); } }
  catch (e) { console.error('MongoDB save failed:', e.message); }
  finally { saving = false; }
}
const save = () => { if (col) { pending = true; flush(); } else fs.writeFileSync(FILE, JSON.stringify(db, null, 1)); };
function seed() {
  const U = (name, email, pw, role, dept, year) => ({ id: uid(), name, email, pass: hash(pw), role, dept, year });
  const users = [
    U('College Admin', 'admin@college.edu', 'admin123', 'admin', 'Administration', 0),
    U('Coding Club', 'org@college.edu', 'org123', 'organizer', 'CSE', 0),
    U('Rahul Sharma', 'rahul@college.edu', 'student123', 'student', 'CSE', 3),
    U('Ananya Rao', 'ananya@college.edu', 'student123', 'student', 'ECE', 2),
    U('Arjun Kumar', 'arjun@college.edu', 'student123', 'student', 'AI&DS', 3),
    U('Priya Nair', 'priya@college.edu', 'student123', 'student', 'EEE', 1),
  ];
  const org = users[1].id;
  const E = (title, category, tagline, d, venue, capacity, color, extra = {}) => ({
    id: uid(), title, category, tagline, description: tagline + ' Open to all departments. Bring your college ID. Certificates are issued after verified participation.',
    date: day(d), venue, capacity, color, organizerId: org, views: Math.floor(Math.random() * 200), mode: 'Offline', teamEvent: false, ...extra });
  const events = [
    E('Hackathon 2026', 'Technical', 'Build. Innovate. Solve.', 6, 'Innovation Lab', 100, '#6d28d9,#db2777', { teamEvent: true, points: 20 }),
    E('Code Sprint', 'Technical', '3 hours. 5 problems. One winner.', 10, 'CS Block Lab 2', 60, '#0ea5e9,#6366f1'),
    E('AI Workshop', 'Workshop', 'Hands-on intro to machine learning.', 3, 'Seminar Hall', 40, '#10b981,#0891b2', { mode: 'Online' }),
    E('Annual Sports Fest', 'Sports', 'Track, field and team glory.', 14, 'Main Ground', 200, '#f97316,#dc2626'),
    E('Inter-College Football Tournament', 'Sports', '8 teams. One trophy.', 20, 'Football Ground', 16, '#16a34a,#065f46', { teamEvent: true }),
    E('Cultural Fest', 'Cultural', 'Dance, drama, music and more.', 8, 'Open Air Theatre', 300, '#ec4899,#f59e0b'),
    E('Battle of Bands', 'Cultural', 'Loudest night on campus.', 12, 'Auditorium', 12, '#a855f7,#ef4444'),
    E('Quiz Championship', 'Technical', 'Test your general knowledge.', 5, 'Room 204', 3, '#eab308,#ea580c'),
    E('Photography Walk', 'Cultural', 'Capture the campus at golden hour.', -20, 'Campus Gardens', 30, '#14b8a6,#3b82f6'),
  ];
  const rules = { Technical: 20, Cultural: 10, Sports: 15, Workshop: 5, winnerBonus: 30 };
  const regs = [], audit = [];
  const R = (u, e, o = {}) => regs.push({ id: uid(), code: 'REG-' + e.id.slice(0, 4).toUpperCase() + '-' + String(regs.length + 100), eventId: e.id, userId: u.id, status: 'registered', checkedIn: false, awarded: false, points: 0, rating: null, at: Date.now() - Math.random() * 2 * DAY, ...o });
  users.slice(2).forEach(u => { R(u, events[0]); R(u, events[5]); });
  users.slice(2, 5).forEach(u => R(u, events[1]));
  users.slice(2).forEach((u, i) => R(u, events[8], { checkedIn: true, awarded: true, points: 10 + i * 5, rating: 4 + (i % 2) }));
  users.slice(2).forEach((u, i) => R(u, events[7], i === 3 ? { status: 'waitlist' } : {})); // quiz is full: 3 in, 1 waitlisted
  return { users, events, regs, rules, audit };
}
async function init() {
  if (process.env.MONGODB_URI) {
    mongo = new MongoClient(process.env.MONGODB_URI, { serverSelectionTimeoutMS: 15000 });
    await mongo.connect();
    col = mongo.db(process.env.DB_NAME || 'campusportal').collection('state');
    const doc = await col.findOne({ _id: 'main' });
    if (doc) { delete doc._id; db = doc; } else { db = seed(); await col.replaceOne({ _id: 'main' }, { _id: 'main', ...db }, { upsert: true }); }
    console.log('Connected to MongoDB Atlas');
  } else {
    db = fs.existsSync(FILE) ? JSON.parse(fs.readFileSync(FILE)) : (d => (db = d, save(), d))(seed());
    console.log('No MONGODB_URI set - using local data.json');
  }
}

// ---------- auth ----------
const sig = b => crypto.createHmac('sha256', SECRET).update(b).digest('base64url');
const sign = u => { const b = Buffer.from(JSON.stringify({ id: u.id, exp: Date.now() + 7 * DAY })).toString('base64url'); return b + '.' + sig(b); };
const auth = (...roles) => (req, res, next) => {
  let user;
  try {
    const [b, s] = (req.headers.authorization || '').replace('Bearer ', '').split('.');
    if (!b || s !== sig(b)) throw 0;
    const p = JSON.parse(Buffer.from(b, 'base64url'));
    if (p.exp < Date.now()) throw 0;
    user = db.users.find(u => u.id === p.id);
    if (!user) throw 0;
  } catch { return res.status(401).json({ error: 'Please log in' }); }
  if (roles.length && !roles.includes(user.role)) return res.status(403).json({ error: 'Not allowed' });
  req.user = user; next();
};
const pub = u => ({ id: u.id, name: u.name, email: u.email, role: u.role, dept: u.dept, year: u.year });
const log = (u, action) => { db.audit.unshift({ at: Date.now(), by: u.name, action }); db.audit.length = Math.min(db.audit.length, 200); };
const attempts = {};
const limit = (req, res, next) => { const k = req.ip, n = Date.now(); attempts[k] = (attempts[k] || []).filter(t => n - t < 6e4); if (attempts[k].length >= 10) return res.status(429).json({ error: 'Too many attempts, wait a minute' }); attempts[k].push(n); next(); };

// ---------- helpers ----------
const pts = e => e.points ?? db.rules[e.category] ?? 5;
const view = e => {
  const rs = db.regs.filter(r => r.eventId === e.id), reg = rs.filter(r => r.status === 'registered').length;
  const recent = rs.filter(r => Date.now() - r.at < 2 * DAY).length, rated = rs.filter(r => r.rating);
  return { ...e, registered: reg, waitlist: rs.length - reg, remaining: Math.max(0, e.capacity - reg), soldOut: reg >= e.capacity,
    closed: new Date(e.date) < Date.now(), points: pts(e), recent, rating: rated.length ? +(rated.reduce((a, r) => a + r.rating, 0) / rated.length).toFixed(1) : null,
    trending: Math.round(reg + recent * 5 + e.views * 0.2) };
};
const need = (v, msg) => { if (!v) throw Object.assign(new Error(msg), { status: 400 }); };
const wrap = fn => (req, res) => { try { res.json(fn(req, res)); } catch (e) { res.status(e.status || 500).json({ error: e.message }); } };
const canManage = (u, e) => u.role === 'admin' || e.organizerId === u.id;

// ---------- app ----------
const app = express();
app.use(express.json({ limit: '100kb' }), express.static(path.join(__dirname, 'public')));

app.post('/api/register', limit, wrap(req => {
  const { name, email, password, dept, year } = req.body;
  need(name?.trim() && /^\S+@\S+\.\S+$/.test(email || '') && password?.length >= 6, 'Name, valid email and 6+ char password required');
  need(!db.users.some(u => u.email === email.toLowerCase()), 'Email already registered');
  const u = { id: uid(), name: name.trim(), email: email.toLowerCase(), pass: hash(password), role: 'student', dept: dept || 'CSE', year: +year || 1 };
  db.users.push(u); save(); return { token: sign(u), user: pub(u) };
}));
app.post('/api/login', limit, wrap(req => {
  const u = db.users.find(u => u.email === (req.body.email || '').toLowerCase());
  need(u && verifyPw(req.body.password || '', u.pass), 'Invalid email or password');
  return { token: sign(u), user: pub(u) };
}));
app.get('/api/me', auth(), wrap(req => pub(req.user)));

app.get('/api/events', wrap(req => {
  const q = (req.query.q || '').toLowerCase();
  let list = db.events.filter(e => !q || (e.title + e.category + e.tagline).toLowerCase().includes(q));
  if (req.query.category) list = list.filter(e => e.category === req.query.category);
  return list.map(view);
}));
app.get('/api/events/:id', wrap(req => {
  const e = db.events.find(e => e.id === req.params.id); need(e, 'Event not found');
  e.views++; save(); return view(e);
}));
app.post('/api/events', auth('organizer', 'admin'), wrap(req => {
  const b = req.body; need(b.title?.trim() && b.date && b.venue && +b.capacity > 0, 'Title, date, venue and capacity are required');
  const e = { id: uid(), title: b.title.trim(), category: b.category || 'Technical', tagline: b.tagline || '', description: b.description || b.tagline || '', date: new Date(b.date).toISOString(),
    venue: b.venue, capacity: +b.capacity, color: ['#6d28d9,#db2777', '#0ea5e9,#6366f1', '#f97316,#dc2626', '#10b981,#0891b2'][db.events.length % 4], organizerId: req.user.id, views: 0, mode: b.mode || 'Offline', teamEvent: !!b.teamEvent };
  if (b.points !== '' && b.points != null) e.points = +b.points;
  db.events.push(e); log(req.user, `Created event ${e.title}`); save(); return view(e);
}));

app.post('/api/events/:id/register', auth('student'), wrap(req => {
  const e = db.events.find(e => e.id === req.params.id); need(e, 'Event not found');
  const v = view(e); need(!v.closed, 'Registration closed');
  need(!db.regs.some(r => r.eventId === e.id && r.userId === req.user.id), 'You are already registered');
  const r = { id: uid(), code: 'REG-' + e.id.slice(0, 4).toUpperCase() + '-' + String(db.regs.length + 100), eventId: e.id, userId: req.user.id,
    status: v.soldOut ? 'waitlist' : 'registered', checkedIn: false, awarded: false, points: 0, rating: null, at: Date.now() };
  db.regs.push(r); save(); return r;
}));
app.delete('/api/events/:id/register', auth('student'), wrap(req => {
  const i = db.regs.findIndex(r => r.eventId === req.params.id && r.userId === req.user.id); need(i >= 0, 'Not registered');
  need(!db.regs[i].checkedIn, 'Cannot cancel after check-in');
  const [old] = db.regs.splice(i, 1);
  if (old.status === 'registered') { const next = db.regs.filter(r => r.eventId === old.eventId && r.status === 'waitlist').sort((a, b) => a.at - b.at)[0]; if (next) next.status = 'registered'; }
  save(); return { ok: true };
}));
app.get('/api/my/registrations', auth(), wrap(req =>
  db.regs.filter(r => r.userId === req.user.id).map(r => ({ ...r, event: view(db.events.find(e => e.id === r.eventId)), student: pub(req.user) })).sort((a, b) => new Date(b.event.date) - new Date(a.event.date))));
app.post('/api/registrations/:id/rate', auth('student'), wrap(req => {
  const r = db.regs.find(r => r.id === req.params.id && r.userId === req.user.id); need(r?.checkedIn, 'Only attended events can be rated');
  need([1, 2, 3, 4, 5].includes(+req.body.rating), 'Rating 1-5'); r.rating = +req.body.rating; save(); return { ok: true };
}));

// organizer
app.get('/api/events/:id/registrations', auth('organizer', 'admin'), wrap(req => {
  const e = db.events.find(e => e.id === req.params.id); need(e && canManage(req.user, e), 'Not your event');
  return db.regs.filter(r => r.eventId === e.id).map(r => ({ ...r, student: pub(db.users.find(u => u.id === r.userId)) }));
}));
app.post('/api/checkin', auth('organizer', 'admin'), wrap(req => {
  const r = db.regs.find(r => r.code === (req.body.code || '').trim().toUpperCase()); need(r, 'Invalid pass code');
  const e = db.events.find(e => e.id === r.eventId); need(canManage(req.user, e), 'This pass is for an event you do not manage');
  need(r.status === 'registered', 'Student is only on the waitlist');
  if (r.checkedIn) throw Object.assign(new Error('Duplicate scan: already checked in'), { status: 409 });
  r.checkedIn = true; log(req.user, `Checked in ${db.users.find(u => u.id === r.userId).name} for ${e.title}`); save();
  return { ok: true, student: db.users.find(u => u.id === r.userId).name, event: e.title };
}));
app.post('/api/registrations/:id/award', auth('organizer', 'admin'), wrap(req => {
  const r = db.regs.find(r => r.id === req.params.id); need(r, 'Not found');
  const e = db.events.find(e => e.id === r.eventId); need(canManage(req.user, e), 'Not your event');
  need(r.checkedIn, 'Verify attendance before awarding points'); need(!r.awarded, 'Points already awarded');
  r.points = pts(e) + (req.body.winner ? db.rules.winnerBonus : 0); r.awarded = true; if (req.body.winner) r.result = 'Winner';
  log(req.user, `Awarded ${r.points} pts to ${db.users.find(u => u.id === r.userId).name} (${e.title})`); save(); return r;
}));

// profile, leaderboard, certificates
const totals = () => db.users.filter(u => u.role === 'student').map(u => {
  const rs = db.regs.filter(r => r.userId === u.id && r.awarded);
  return { ...pub(u), points: rs.reduce((a, r) => a + r.points, 0), events: rs.length };
}).sort((a, b) => b.points - a.points);
app.get('/api/leaderboard', wrap(() => totals()));
app.get('/api/profile', auth(), wrap(req => {
  const t = totals(), me = t.find(x => x.id === req.user.id) || { ...pub(req.user), points: 0, events: 0 };
  const certs = db.regs.filter(r => r.userId === req.user.id && r.awarded).map(r => ({ id: r.id, event: db.events.find(e => e.id === r.eventId).title, date: db.events.find(e => e.id === r.eventId).date, points: r.points, result: r.result }));
  return { ...me, rank: t.findIndex(x => x.id === req.user.id) + 1, certs };
}));
app.get('/api/verify/:id', wrap(req => {
  const r = db.regs.find(r => r.id === req.params.id && r.awarded); need(r, 'Certificate not found');
  const e = db.events.find(e => e.id === r.eventId), u = db.users.find(u => u.id === r.userId);
  return { valid: true, student: u.name, event: e.title, date: e.date, points: r.points, result: r.result || 'Participant' };
}));

// admin
app.get('/api/admin/stats', auth('admin'), wrap(() => {
  const byCat = {}, byDept = {};
  db.regs.forEach(r => { const e = db.events.find(e => e.id === r.eventId), u = db.users.find(u => u.id === r.userId); byCat[e.category] = (byCat[e.category] || 0) + 1; byDept[u.dept] = (byDept[u.dept] || 0) + 1; });
  return { students: db.users.filter(u => u.role === 'student').length, events: db.events.length, registrations: db.regs.length, points: db.regs.reduce((a, r) => a + r.points, 0),
    certificates: db.regs.filter(r => r.awarded).length, byCat, byDept, rules: db.rules, audit: db.audit.slice(0, 15) };
}));
app.put('/api/admin/rules', auth('admin'), wrap(req => {
  for (const [k, v] of Object.entries(req.body)) { need(k in db.rules && Number.isFinite(+v) && +v >= 0, 'Invalid rule'); if (db.rules[k] !== +v) { log(req.user, `Changed rule ${k}: ${db.rules[k]} -> ${+v}`); db.rules[k] = +v; } }
  save(); return db.rules;
}));

init().then(() => {
  app.listen(PORT, () => console.log(`Campus Portal running at http://localhost:${PORT}`));
  const bye = async () => { try { if (col) { pending = true; await flush(); await mongo.close(); } } finally { process.exit(0); } };
  process.on('SIGINT', bye); process.on('SIGTERM', bye);
}).catch(e => { console.error('Startup failed:', e.message); process.exit(1); });
