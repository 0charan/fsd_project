const $ = s => document.querySelector(s), app = $('#app');
let user = JSON.parse(localStorage.user || 'null'), token = localStorage.token;
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const fmt = d => new Date(d).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
const toast = m => { const t = $('#toast'); t.textContent = m; t.style.display = 'block'; setTimeout(() => t.style.display = 'none', 2600); };
async function api(url, method = 'GET', body) {
  const r = await fetch('/api' + url, { method, headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}) }, body: body ? JSON.stringify(body) : undefined });
  const j = await r.json().catch(() => ({})); if (!r.ok) throw new Error(j.error || 'Something went wrong'); return j;
}
const act = async (fn, ok) => { try { await fn(); if (ok) toast(ok); route(); } catch (e) { toast('⚠ ' + e.message); } };
window.act = act; window.api = api;
const grad = c => `linear-gradient(135deg,${c})`;

function nav() {
  const r = user?.role;
  $('#nav').innerHTML = `<a class="logo" href="#/">CampusPulse</a><a href="#/">Home</a><a href="#/explore">Explore</a><a href="#/leaderboard">Leaderboard</a>
  ${r === 'student' ? '<a href="#/me">My Activity</a>' : ''}${r === 'organizer' || r === 'admin' ? '<a href="#/organizer">Organizer</a>' : ''}${r === 'admin' ? '<a href="#/admin">Admin</a>' : ''}
  <span class="sp"></span><input class="search hide-m" placeholder="Search events…" onkeydown="if(event.key==='Enter')location.hash='#/explore/'+encodeURIComponent(this.value)">
  ${user ? `<span class="mut hide-m">${esc(user.name)}</span><button class="btn ghost sm" onclick="logout()">Logout</button>` : '<a class="btn sm" href="#/login">Login</a>'}`;
}
window.logout = () => { localStorage.clear(); user = token = null; location.hash = '#/'; route(); };

const card = e => `<a class="card" href="#/event/${e.id}"><div class="img" style="background:${grad(e.color)}">${esc(e.title)}</div>
 <div class="body"><span>📅 ${fmt(e.date)} · 📍 ${esc(e.venue)}</span><span>👥 ${e.registered}/${e.capacity} · ⭐ ${e.points} pts</span>
 <span>${e.closed ? '<span class="tag">Completed</span>' : e.soldOut ? '<span class="tag red">SOLD OUT</span>' : `<span class="tag green">${e.remaining} slots left</span>`} <span class="tag">${e.category}</span></span></div></a>`;
const rowOf = (t, list) => list.length ? `<h2>${t}</h2><div class="row">${list.map(card).join('')}</div>` : '';

async function home() {
  const ev = await api('/events'), up = ev.filter(e => !e.closed).sort((a, b) => new Date(a.date) - new Date(b.date));
  const feat = [...up].sort((a, b) => b.trending - a.trending)[0];
  app.innerHTML = `<div class="hero" style="background:${grad(feat.color)}"><span class="tag" style="width:fit-content">🔥 Trending now</span><h1>${esc(feat.title)}</h1><p>${esc(feat.tagline)}</p>
   <div class="meta"><span>📅 ${fmt(feat.date)}</span><span>📍 ${esc(feat.venue)}</span><span>👥 ${feat.registered} registered</span></div>
   <div><a class="btn" href="#/event/${feat.id}">View Event</a></div></div>
   <h1 style="margin:0">Discover. Participate. Earn.</h1><p class="mut">One place for everything happening on campus.</p>
   ${rowOf('🔥 Trending Now', [...up].sort((a, b) => b.trending - a.trending).slice(0, 6))}${rowOf('📅 Upcoming', up)}
   ${['Technical', 'Cultural', 'Sports', 'Workshop'].map(c => rowOf({ Technical: '💻 Technical', Cultural: '🎨 Cultural', Sports: '🏆 Sports', Workshop: '🛠 Workshops' }[c], ev.filter(e => e.category === c))).join('')}
   ${rowOf('🆕 Recently Added', [...ev].reverse().slice(0, 5))}`;
}
async function explore(q = '') {
  q = decodeURIComponent(q);
  app.innerHTML = `<h2>Explore events</h2><div style="display:flex;gap:10px;margin-bottom:16px"><input id="q" value="${esc(q)}" placeholder="Search hackathon, football, workshop…">
   <select id="cat" style="max-width:180px"><option value="">All categories</option>${['Technical', 'Cultural', 'Sports', 'Workshop'].map(c => `<option>${c}</option>`).join('')}</select>
   <select id="sort" style="max-width:160px"><option value="trending">Trending</option><option value="date">Upcoming</option><option value="rating">Top rated</option></select></div><div class="grid" id="res"></div>`;
  const load = async () => {
    let l = await api(`/events?q=${encodeURIComponent($('#q').value)}&category=${$('#cat').value}`), s = $('#sort').value;
    l.sort((a, b) => s === 'date' ? new Date(a.date) - new Date(b.date) : s === 'rating' ? (b.rating || 0) - (a.rating || 0) : b.trending - a.trending);
    $('#res').innerHTML = l.map(card).join('') || '<p class="mut">No events match your search.</p>';
  };
  ['q', 'cat', 'sort'].forEach(i => $('#' + i).oninput = load); load();
}
async function eventPage(id) {
  const e = await api('/events/' + id); let mine;
  if (user?.role === 'student') mine = (await api('/my/registrations')).find(r => r.eventId === id);
  const btn = !user ? '<a class="btn" href="#/login">Login to register</a>' : user.role !== 'student' ? '' : mine ? `<span class="tag">${mine.status === 'waitlist' ? '⏳ On waitlist' : '✅ Registered'}</span> <button class="btn ghost" onclick="act(()=>api('/events/${id}/register','DELETE'),'Registration cancelled')">Cancel</button>`
    : e.closed ? '<span class="tag">Registration closed</span>' : `<button class="btn" onclick="act(()=>api('/events/${id}/register','POST'),'Done!')">${e.soldOut ? 'Join Waitlist' : 'Register Now'}</button>`;
  app.innerHTML = `<div class="hero" style="background:${grad(e.color)}"><span class="tag" style="width:fit-content">${e.category}${e.teamEvent ? ' · Team event' : ''}</span><h1>${esc(e.title)}</h1><p>${esc(e.tagline)}</p>
   <div class="meta"><span>📅 ${fmt(e.date)}</span><span>📍 ${esc(e.venue)} (${e.mode})</span><span>👥 ${e.registered}/${e.capacity}${e.soldOut ? ' — SOLD OUT' : ''}</span><span>⭐ ${e.points} points</span>${e.rating ? `<span>${e.rating} ★ rating</span>` : ''}</div><div>${btn}</div></div>
   <div class="two"><div class="panel"><h3>About</h3><p>${esc(e.description)}</p></div><div class="panel"><h3>Registration</h3><p class="mut">${e.remaining} of ${e.capacity} slots remaining<br>${e.waitlist} on waitlist<br>+${e.recent} registrations recently</p></div></div>
   ${mine && mine.status === 'registered' ? `<h2>Your digital pass</h2>${pass(mine)}` : ''}
   ${mine?.checkedIn ? `<div class="panel">Rate this event: ${[1, 2, 3, 4, 5].map(n => `<button class="btn ghost sm" onclick="act(()=>api('/registrations/${mine.id}/rate','POST',{rating:${n}}),'Thanks for the feedback')">${'★'.repeat(n)}</button>`).join(' ')}</div>` : ''}`;
  qrs();
}
const pass = r => `<div class="pass"><div class="q" data-qr="${r.code}"></div><div><b>${esc(r.event.title)}</b><br>${esc(r.student.name)} · ${esc(r.student.dept)}<br>ID: <b>${r.code}</b><br>${fmt(r.event.date)} · ${esc(r.event.venue)}<br>${r.checkedIn ? '✅ Checked in' : 'Not checked in'}</div></div>`;
const qrs = () => document.querySelectorAll('[data-qr]').forEach(el => { el.innerHTML = ''; new QRCode(el, { text: el.dataset.qr, width: 96, height: 96 }); });

function loginPage(reg) {
  app.innerHTML = `<div class="panel" style="max-width:420px;margin:40px auto"><h2 style="margin-top:0">${reg ? 'Create account' : 'Welcome back'}</h2>
   <form id="f">${reg ? '<input name="name" placeholder="Full name" required>' : ''}<input name="email" type="email" placeholder="Email" required><input name="password" type="password" placeholder="Password" required>
   ${reg ? '<select name="dept"><option>CSE</option><option>ECE</option><option>EEE</option><option>MECH</option><option>CIVIL</option><option>AI&amp;DS</option></select><input name="year" type="number" min="1" max="4" placeholder="Year (1-4)">' : ''}
   <button class="btn">${reg ? 'Sign up' : 'Login'}</button></form><p class="mut">${reg ? '<a href="#/login">Have an account? Login</a>' : '<a href="#/register">New here? Sign up</a>'}</p>
   ${reg ? '' : '<p class="mut" style="font-size:12px">Demo: rahul@college.edu / student123 · org@college.edu / org123 · admin@college.edu / admin123</p>'}</div>`;
  $('#f').onsubmit = ev => { ev.preventDefault(); act(async () => { const r = await api(reg ? '/register' : '/login', 'POST', Object.fromEntries(new FormData(ev.target))); token = r.token; user = r.user; localStorage.token = token; localStorage.user = JSON.stringify(user); location.hash = user.role === 'student' ? '#/me' : user.role === 'admin' ? '#/admin' : '#/organizer'; }); };
}
async function me() {
  if (!user) return location.hash = '#/login';
  const [p, regs, ev] = await Promise.all([api('/profile'), api('/my/registrations'), api('/events')]);
  const next = regs.filter(r => !r.event.closed && r.status === 'registered').sort((a, b) => new Date(a.event.date) - new Date(b.event.date))[0];
  const rec = ev.filter(e => !e.closed && !regs.some(r => r.eventId === e.id)).sort((a, b) => b.trending - a.trending).slice(0, 6);
  app.innerHTML = `<h1>Welcome back, ${esc(user.name.split(' ')[0])} 👋</h1>
   <div class="grid"><div class="panel"><div class="mut">Activity Score</div><div class="stat">${p.points}</div><span class="tag">Rank #${p.rank}</span></div><div class="panel"><div class="mut">Events completed</div><div class="stat">${p.events}</div></div>
   <div class="panel"><div class="mut">Certificates</div><div class="stat">${p.certs.length}</div></div><div class="panel"><div class="mut">Next event</div><b>${next ? esc(next.event.title) + '<br>' + fmt(next.event.date) : 'Nothing booked yet'}</b></div></div>
   <h2>My registrations &amp; passes</h2>${regs.map(r => `<div class="panel" style="margin-bottom:10px"><a href="#/event/${r.eventId}"><b>${esc(r.event.title)}</b></a> <span class="tag">${r.status}</span> ${r.awarded ? `<span class="tag green">+${r.points} pts verified</span>` : ''}${r.status === 'registered' && !r.event.closed ? pass(r) : ''}</div>`).join('') || '<p class="mut">You have not registered for anything yet.</p>'}
   <h2>Participation timeline &amp; certificates</h2>${p.certs.map(c => `<div class="panel" style="margin-bottom:10px;display:flex;justify-content:space-between;align-items:center"><span>🏅 ${esc(c.event)} · ${fmt(c.date)} · <b>+${c.points}</b></span><a class="btn sm" href="#/cert/${c.id}">Certificate</a></div>`).join('') || '<p class="mut">Verified participation will appear here.</p>'}
   ${rowOf('🎯 Recommended for you', rec)}`;
  qrs();
}
async function cert(id) {
  try { const c = await api('/verify/' + id); app.innerHTML = `<div class="cert"><h3>CERTIFICATE OF ${c.result.toUpperCase()}</h3><p>This certifies that</p><h1>${esc(c.student)}</h1><p>took part in <b>${esc(c.event)}</b> on ${fmt(c.date)}<br>Points: ${c.points}</p>
   <div data-qr="${location.origin}/#/cert/${id}" style="display:inline-block"></div><p>Certificate ID: CERT-${id.toUpperCase()}<br><b style="color:green">✔ Certificate Valid</b></p></div><button class="btn noprint" onclick="print()">Print / Save PDF</button>`; qrs(); }
  catch { app.innerHTML = '<div class="cert"><h2 style="color:#b91c1c">✖ Certificate not valid</h2></div>'; }
}
async function board() {
  const l = await api('/leaderboard');
  app.innerHTML = `<h2>🏆 Leaderboard</h2><div class="panel"><table><tr><th>#</th><th>Student</th><th>Dept</th><th>Events</th><th>Points</th></tr>${l.map((s, i) => `<tr><td>${['🥇', '🥈', '🥉'][i] || i + 1}</td><td>${esc(s.name)}</td><td>${esc(s.dept)}</td><td>${s.events}</td><td><b>${s.points}</b></td></tr>`).join('')}</table></div>`;
}
async function organizer() {
  if (!['organizer', 'admin'].includes(user?.role)) return location.hash = '#/login';
  const ev = (await api('/events')).filter(e => user.role === 'admin' || e.organizerId === user.id);
  app.innerHTML = `<h2>Organizer dashboard</h2><div class="two"><div>${ev.map(e => `<div class="panel" style="margin-bottom:10px;display:flex;justify-content:space-between;align-items:center"><span><b>${esc(e.title)}</b><br><span class="mut">${e.registered}/${e.capacity} registered · ${e.waitlist} waitlist</span></span><button class="btn sm" onclick="regs('${e.id}')">Manage</button></div>`).join('')}
   <div id="mg"></div></div><div class="panel"><h3 style="margin-top:0">Scan / enter pass code</h3><form id="ci"><input name="code" placeholder="REG-XXXX-101" required><button class="btn">Check in</button></form>
   <h3>Create event</h3><form id="ne"><input name="title" placeholder="Title" required><input name="tagline" placeholder="Tagline"><select name="category"><option>Technical</option><option>Cultural</option><option>Sports</option><option>Workshop</option></select>
   <input name="date" type="datetime-local" required><input name="venue" placeholder="Venue" required><input name="capacity" type="number" placeholder="Capacity" required><input name="points" type="number" placeholder="Points (blank = category rule)"><button class="btn">Create</button></form></div></div>`;
  $('#ci').onsubmit = e => { e.preventDefault(); act(async () => { const r = await api('/checkin', 'POST', Object.fromEntries(new FormData(e.target))); toast(`✅ ${r.student} checked in for ${r.event}`); e.target.reset(); }); };
  $('#ne').onsubmit = e => { e.preventDefault(); act(() => api('/events', 'POST', Object.fromEntries(new FormData(e.target))), 'Event created'); };
}
window.regs = async id => {
  const r = await api(`/events/${id}/registrations`);
  $('#mg').innerHTML = `<div class="panel"><table><tr><th>Student</th><th>Code</th><th>Status</th><th></th></tr>${r.map(x => `<tr><td>${esc(x.student.name)}<br><span class="mut">${esc(x.student.dept)}</span></td><td>${x.code}</td><td>${x.status}${x.checkedIn ? ' ✅' : ''}</td>
   <td>${x.awarded ? `+${x.points}` : x.checkedIn ? `<button class="btn sm" onclick="aw('${x.id}','${id}')">Award</button> <button class="btn ghost sm" onclick="aw('${x.id}','${id}',true)">Winner</button>` : ''}</td></tr>`).join('') || '<tr><td>No registrations yet</td></tr>'}</table></div>`;
};
window.aw = async (rid, eid, winner) => { try { await api(`/registrations/${rid}/award`, 'POST', { winner }); toast('Points awarded'); regs(eid); } catch (e) { toast('⚠ ' + e.message); } };
async function admin() {
  if (user?.role !== 'admin') return location.hash = '#/login';
  const s = await api('/admin/stats'), max = o => Math.max(...Object.values(o), 1);
  const bars = o => Object.entries(o).map(([k, v]) => `<div style="margin:8px 0">${esc(k)} <b>${v}</b><div class="bar" style="width:${v / max(o) * 100}%"></div></div>`).join('');
  app.innerHTML = `<h2>Admin dashboard</h2><div class="grid">${[['Students', s.students], ['Events', s.events], ['Registrations', s.registrations], ['Points awarded', s.points], ['Certificates', s.certificates]].map(([k, v]) => `<div class="panel"><div class="mut">${k}</div><div class="stat">${v}</div></div>`).join('')}</div>
   <div class="grid" style="margin-top:16px"><div class="panel"><h3>By department</h3>${bars(s.byDept)}</div><div class="panel"><h3>By category</h3>${bars(s.byCat)}</div>
   <div class="panel"><h3>Points rules</h3><form id="rl">${Object.entries(s.rules).map(([k, v]) => `<label class="mut">${k}<input name="${k}" type="number" value="${v}"></label>`).join('')}<button class="btn">Save rules</button></form></div></div>
   <h2>Audit log</h2><div class="panel"><table>${s.audit.map(a => `<tr><td>${new Date(a.at).toLocaleString()}</td><td>${esc(a.by)}</td><td>${esc(a.action)}</td></tr>`).join('') || '<tr><td>No actions yet</td></tr>'}</table></div>`;
  $('#rl').onsubmit = e => { e.preventDefault(); act(() => api('/admin/rules', 'PUT', Object.fromEntries(new FormData(e.target))), 'Rules updated'); };
}
async function route() {
  nav(); const [, p, a] = location.hash.split('/'); window.scrollTo(0, 0);
  try {
    if (!p) await home(); else if (p === 'explore') await explore(a); else if (p === 'event') await eventPage(a); else if (p === 'login') loginPage(); else if (p === 'register') loginPage(true);
    else if (p === 'me') await me(); else if (p === 'leaderboard') await board(); else if (p === 'organizer') await organizer(); else if (p === 'admin') await admin(); else if (p === 'cert') await cert(a);
  } catch (e) { app.innerHTML = `<div class="panel">⚠ ${esc(e.message)}</div>`; if (/log in/i.test(e.message)) { localStorage.clear(); user = token = null; nav(); } }
}
addEventListener('hashchange', route); route();
